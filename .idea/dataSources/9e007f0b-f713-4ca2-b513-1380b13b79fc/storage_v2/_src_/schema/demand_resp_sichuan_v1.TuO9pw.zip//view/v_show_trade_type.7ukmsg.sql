create definer = root@localhost view v_show_trade_type as
select `a`.`serial`            AS `sortNo`,
       `a`.`trade_code_i`      AS `trade_code`,
       `a`.`trade_code_i_name` AS `trade`,
       `a`.`superior_trade`    AS `SUPERIOR_TRADE`
from `demand_resp_sichuan_v1`.`ctrl_show_trade_type` `a`
group by `a`.`trade_code_i`
union
select 99999 AS `sortNo`, 'other' AS `trade_code`, '其他' AS `trade`, '' AS `SUPERIOR_TRADE`
order by `sortNo`;

