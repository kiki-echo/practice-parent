create definer = root@`%` view v_o_org as
select `survey-sync3`.`o_org`.`ORG_NO` AS `id`, `survey-sync3`.`o_org`.`ORG_NAME` AS `name`
from `survey-sync3`.`o_org`;

-- comment on column v_o_org.id not supported: 供电单位编号

-- comment on column v_o_org.name not supported: 供电单位名称

