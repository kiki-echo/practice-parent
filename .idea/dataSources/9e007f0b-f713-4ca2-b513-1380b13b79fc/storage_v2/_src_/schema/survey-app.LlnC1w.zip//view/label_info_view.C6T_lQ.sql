create definer = root@`%` view label_info_view as
select `survey`.`label_info`.`id`          AS `id`,
       `survey`.`label_info`.`name`        AS `name`,
       `survey`.`label_info`.`description` AS `description`,
       `survey`.`label_info`.`value`       AS `value`,
       `survey`.`label_info`.`label_group` AS `label_group`,
       `survey`.`label_info`.`is_enable`   AS `is_enable`,
       `survey`.`label_info`.`is_deleted`  AS `is_deleted`,
       `survey`.`label_info`.`create_time` AS `create_time`,
       `survey`.`label_info`.`update_time` AS `update_time`
from `survey`.`label_info`;

-- comment on column label_info_view.id not supported: 主键id

-- comment on column label_info_view.name not supported: 标签名 标签名字唯一

-- comment on column label_info_view.description not supported: 标签描述

-- comment on column label_info_view.value not supported: 标签规则

-- comment on column label_info_view.label_group not supported: 简化标签组 名字相同组唯一

-- comment on column label_info_view.is_enable not supported: 是否启用 1 启用 0 未启用

-- comment on column label_info_view.is_deleted not supported: 是否删除 0 未删 1 删除

-- comment on column label_info_view.create_time not supported: 创建时间

-- comment on column label_info_view.update_time not supported: 更新时间

