create definer = root@`%` view label_mapper_ref_view as
select `survey`.`label_mapper_ref`.`id`          AS `id`,
       `survey`.`label_mapper_ref`.`key`         AS `key`,
       `survey`.`label_mapper_ref`.`key_type`    AS `key_type`,
       `survey`.`label_mapper_ref`.`label`       AS `label`,
       `survey`.`label_mapper_ref`.`label_group` AS `label_group`,
       `survey`.`label_mapper_ref`.`is_deleted`  AS `is_deleted`,
       `survey`.`label_mapper_ref`.`create_time` AS `create_time`,
       `survey`.`label_mapper_ref`.`update_time` AS `update_time`
from `survey`.`label_mapper_ref`;

-- comment on column label_mapper_ref_view.id not supported: 主键id

-- comment on column label_mapper_ref_view.`key` not supported: 关键字 用户编号/行业编号

-- comment on column label_mapper_ref_view.key_type not supported: 关键字类型 consumer industry

-- comment on column label_mapper_ref_view.label not supported: 标签

-- comment on column label_mapper_ref_view.label_group not supported: 简化标签组

-- comment on column label_mapper_ref_view.is_deleted not supported: 是否删除 0 未删 1 删除

-- comment on column label_mapper_ref_view.create_time not supported: 创建时间

-- comment on column label_mapper_ref_view.update_time not supported: 更新时间

